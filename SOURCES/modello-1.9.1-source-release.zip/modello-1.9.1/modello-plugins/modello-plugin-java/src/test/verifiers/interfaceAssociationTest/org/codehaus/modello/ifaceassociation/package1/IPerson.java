package org.codehaus.modello.ifaceassociation.package1;

public interface IPerson
{
    
}